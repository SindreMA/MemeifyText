<template>
  <q-layout view="lHh Lpr lFf">
    <q-page-container class="LayoutCSS">
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { openURL } from 'quasar'

export default {
  name: 'MyLayout',
  data () {
    return {
      leftDrawerOpen: this.$q.platform.is.desktop
    }
  },
  methods: {
    openURL
  }
}
</script>

<style>
.LayoutCSS {
}

</style>
