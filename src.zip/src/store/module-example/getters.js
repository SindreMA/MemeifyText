/*
export function someGetter (state) {
}
*/
